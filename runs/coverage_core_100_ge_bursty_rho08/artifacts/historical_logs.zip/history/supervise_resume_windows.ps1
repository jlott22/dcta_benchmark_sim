param(
    [int]$Workers = 12,
    [int]$InitialCap = 50000,
    [int]$RetryCap = 50000,
    [int]$MonitorMinutes = 360
)

$ErrorActionPreference = "Stop"

$runRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $runRoot "..\..")).Path
$manifestPath = Join-Path $runRoot "TRANSFER_MANIFEST.json"
$workRoot = Join-Path $runRoot "_transferred_shards"
$statusPath = Join-Path $runRoot "resume_supervisor_state.json"
$monitorPath = Join-Path $runRoot "resume_monitor.jsonl"
$coordinatorPidPath = Join-Path $runRoot "resume_coordinator.pid"
$supervisorPidPath = Join-Path $runRoot "resume_supervisor.pid"
$stdoutPath = Join-Path $runRoot "resume_coordinator_stdout.log"
$stderrPath = Join-Path $runRoot "resume_coordinator_stderr.log"
$combineStdoutPath = Join-Path $runRoot "resume_combine_stdout.log"
$combineStderrPath = Join-Path $runRoot "resume_combine_stderr.log"

if ($Workers -ne 12) {
    throw "This campaign is approved for exactly 12 workers."
}

function Write-AtomicJson {
    param(
        [string]$Path,
        [System.Collections.IDictionary]$Payload
    )
    $temporary = "$Path.tmp"
    $Payload | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Write-SupervisorState {
    param(
        [string]$Stage,
        [string]$Status,
        [hashtable]$Extra = @{}
    )
    $payload = [ordered]@{
        updated_at = (Get-Date).ToString("o")
        stage = $Stage
        status = $Status
        supervisor_pid = $PID
        workers = $Workers
        initial_cap = $InitialCap
        retry_cap = $RetryCap
    }
    foreach ($entry in $Extra.GetEnumerator()) {
        $payload[$entry.Key] = $entry.Value
    }
    Write-AtomicJson -Path $statusPath -Payload $payload
}

function Get-ShardSnapshot {
    param([int]$CoordinatorPid)

    $results = @()
    if (Test-Path -LiteralPath $workRoot) {
        $results = @(Get-ChildItem -LiteralPath $workRoot -Recurse -Filter "worker_result.json" -File)
    }
    $dgaDrop060 = @(
        $results | Where-Object {
            $_.FullName -match "missing[\\/]dga[\\/]gilbert_elliott_drop_0_60_rho_0_8"
        }
    )
    $dgaElapsed = @(
        $dgaDrop060 | ForEach-Object {
            try {
                [double](Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).elapsed_seconds
            }
            catch {
                $null
            }
        } | Where-Object { $null -ne $_ }
    )
    $workersRunning = @(
        Get-CimInstance Win32_Process | Where-Object {
            $_.Name -match "^python" -and
            $_.CommandLine -match "run_snapshot_coverage_trial.py"
        }
    ).Count
    $state = $null
    $campaignStatePath = Join-Path $runRoot "transferred_coverage_state.json"
    if (Test-Path -LiteralPath $campaignStatePath) {
        $state = Get-Content -LiteralPath $campaignStatePath -Raw | ConvertFrom-Json
    }
    $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue |
        Select-Object Name, BatteryStatus, EstimatedChargeRemaining
    $snapshot = [ordered]@{
        timestamp = (Get-Date).ToString("o")
        coordinator_pid = $CoordinatorPid
        coordinator_alive = $null -ne (Get-Process -Id $CoordinatorPid -ErrorAction SilentlyContinue)
        trial_workers_running = $workersRunning
        validated_shards = $results.Count
        dga_drop060_validated = $dgaDrop060.Count
        dga_drop060_mean_hours = if ($dgaElapsed.Count) {
            [math]::Round((($dgaElapsed | Measure-Object -Average).Average / 3600), 3)
        }
        else {
            $null
        }
        campaign_state = $state
        battery = $battery
        free_disk_gib = [math]::Round((Get-PSDrive -Name C).Free / 1GB, 1)
    }
    ($snapshot | ConvertTo-Json -Depth 10 -Compress) |
        Add-Content -LiteralPath $monitorPath -Encoding UTF8
}

function Assert-AndMarkCanonicalComplete {
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $conditionsChecked = 0
    foreach ($condition in $manifest.conditions) {
        $conditionPath = Join-Path $repoRoot $condition.condition_relative
        $trialRows = @(Import-Csv -LiteralPath (Join-Path $conditionPath "trial_summary.csv"))
        $systemRows = @(Import-Csv -LiteralPath (Join-Path $conditionPath "system_performance.csv"))
        $robotRows = @(Import-Csv -LiteralPath (Join-Path $conditionPath "robot_performance.csv"))

        $trialIds = @($trialRows | ForEach-Object { [int]$_.trial_id })
        $systemIds = @($systemRows | ForEach-Object { [int]$_.trial_id })
        $expectedIds = @(0..99)
        if ($trialRows.Count -ne 100 -or $systemRows.Count -ne 100 -or $robotRows.Count -ne 400) {
            throw "Unexpected row counts in $conditionPath"
        }
        if (@($trialIds | Sort-Object -Unique).Count -ne 100 -or
            @($systemIds | Sort-Object -Unique).Count -ne 100 -or
            (Compare-Object $expectedIds ($trialIds | Sort-Object)).Count -ne 0 -or
            (Compare-Object $expectedIds ($systemIds | Sort-Object)).Count -ne 0) {
            throw "Invalid or duplicate trial IDs in $conditionPath"
        }
        $robotGroups = @($robotRows | Group-Object trial_id)
        if ($robotGroups.Count -ne 100 -or @($robotGroups | Where-Object Count -ne 4).Count -ne 0) {
            throw "Expected four robot rows for every trial in $conditionPath"
        }
        $failedRows = @(
            $trialRows + $systemRows + $robotRows |
                Where-Object { $_.trial_status -eq "failed" }
        )
        if ($failedRows.Count -ne 0) {
            throw "Failed rows remain in $conditionPath"
        }
        @(
            "status=0"
            "rows=100"
            "failed_trial_rows=0"
            "finalized_at=$((Get-Date).ToString('o'))"
            "finalized_by=supervise_resume_windows.ps1"
        ) | Set-Content -LiteralPath (Join-Path $conditionPath "_COMPLETE.txt") -Encoding ASCII
        $conditionsChecked++
    }
    if ($conditionsChecked -ne 48) {
        throw "Expected 48 conditions, checked $conditionsChecked"
    }
}

function Assert-CombinedOutputs {
    $combinedRoot = Join-Path $repoRoot "coverage_100_ge_bursty_rho08_combined"
    $trialRows = @(Import-Csv -LiteralPath (Join-Path $combinedRoot "trial_summary.csv"))
    $systemRows = @(Import-Csv -LiteralPath (Join-Path $combinedRoot "system_performance.csv"))
    $robotRows = @(Import-Csv -LiteralPath (Join-Path $combinedRoot "robot_performance.csv"))
    if ($trialRows.Count -ne 4800 -or $systemRows.Count -ne 4800 -or $robotRows.Count -ne 19200) {
        throw "Combined output row counts are incorrect."
    }
    $failed = @(
        $trialRows + $systemRows + $robotRows |
            Where-Object { $_.trial_status -eq "failed" }
    )
    if ($failed.Count -ne 0) {
        throw "Combined outputs contain failed rows."
    }
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class CoveragePowerState {
    [DllImport("kernel32.dll")]
    public static extern uint SetThreadExecutionState(uint flags);
}
"@

$esContinuous = [Convert]::ToUInt32("80000000", 16)
$esSystemRequired = [uint32]0x00000001
$esAwayModeRequired = [uint32]0x00000040

$PID | Set-Content -LiteralPath $supervisorPidPath -Encoding ASCII
try {
    Write-SupervisorState -Stage "preflight" -Status "starting_on_available_power"

    $existing = @(
        Get-CimInstance Win32_Process | Where-Object {
            $_.ProcessId -ne $PID -and
            $_.Name -match "^python" -and
            $_.CommandLine -match "resume_coverage_sharded|run_snapshot_coverage_trial|run_core_ge_bursty"
        }
    )
    if ($existing.Count -ne 0) {
        throw "Refusing to launch because an existing GE process was found."
    }

    [CoveragePowerState]::SetThreadExecutionState(
        $esContinuous -bor $esSystemRequired -bor $esAwayModeRequired
    ) | Out-Null

    $python = (Get-Command python -ErrorAction Stop).Source
    $arguments = @(
        "analysis/resume_coverage_sharded.py",
        "--workers", "$Workers",
        "--initial-cap", "$InitialCap",
        "--retry-cap", "$RetryCap",
        "--execute",
        "--allow-source-machine"
    )
    $coordinator = Start-Process `
        -FilePath $python `
        -ArgumentList $arguments `
        -WorkingDirectory $repoRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutPath `
        -RedirectStandardError $stderrPath `
        -PassThru
    $coordinator.Id | Set-Content -LiteralPath $coordinatorPidPath -Encoding ASCII
    Write-SupervisorState -Stage "coverage_resume" -Status "running" -Extra @{
        coordinator_pid = $coordinator.Id
        stdout = $stdoutPath
        stderr = $stderrPath
    }

    Start-Sleep -Seconds 10
    if ($coordinator.HasExited) {
        throw "Coordinator exited during startup with code $($coordinator.ExitCode)."
    }
    Get-ShardSnapshot -CoordinatorPid $coordinator.Id

    $nextMonitor = (Get-Date).AddMinutes($MonitorMinutes)
    while (-not $coordinator.WaitForExit(60000)) {
        if ((Get-Date) -ge $nextMonitor) {
            Get-ShardSnapshot -CoordinatorPid $coordinator.Id
            $nextMonitor = (Get-Date).AddMinutes($MonitorMinutes)
        }
    }
    Get-ShardSnapshot -CoordinatorPid $coordinator.Id
    if ($coordinator.ExitCode -ne 0) {
        throw "Coordinator exited with code $($coordinator.ExitCode)."
    }

    Write-SupervisorState -Stage "canonical_validation" -Status "running"
    Assert-AndMarkCanonicalComplete

    Write-SupervisorState -Stage "combine" -Status "running"
    $combine = Start-Process `
        -FilePath $python `
        -ArgumentList @("analysis/combine_core_ge_bursty.py", "--suite", "coverage") `
        -WorkingDirectory $repoRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $combineStdoutPath `
        -RedirectStandardError $combineStderrPath `
        -Wait `
        -PassThru
    if ($combine.ExitCode -ne 0) {
        throw "Combiner exited with code $($combine.ExitCode)."
    }
    Assert-CombinedOutputs
    Write-SupervisorState -Stage "all_coverage" -Status "complete" -Extra @{
        recorded_trials = 4800
        failed_trials = 0
        robot_rows = 19200
        combined_root = (Join-Path $repoRoot "coverage_100_ge_bursty_rho08_combined")
    }
}
catch {
    Write-SupervisorState -Stage "supervisor" -Status "failed" -Extra @{
        error = $_.Exception.Message
        script_stack = $_.ScriptStackTrace
    }
    throw
}
finally {
    [CoveragePowerState]::SetThreadExecutionState($esContinuous) | Out-Null
}
