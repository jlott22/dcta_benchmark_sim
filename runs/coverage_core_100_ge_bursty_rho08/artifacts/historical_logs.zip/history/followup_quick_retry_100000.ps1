param(
    [int]$Workers = 12
)

$ErrorActionPreference = "Stop"
$runRoot = $PSScriptRoot
$repoRoot = [IO.Path]::GetFullPath((Join-Path $runRoot "..\.."))
$currentPidPath = Join-Path $runRoot "quick_retry_coordinator.pid"
$followupPidPath = Join-Path $runRoot "quick_retry_100000_coordinator.pid"
$watcherStatePath = Join-Path $runRoot "quick_retry_100000_watcher_state.json"
$stdoutPath = Join-Path $runRoot "quick_retry_100000_stdout.log"
$stderrPath = Join-Path $runRoot "quick_retry_100000_stderr.log"

function Write-WatcherState {
    param(
        [string]$Status,
        [hashtable]$Extra = @{}
    )
    $payload = @{
        updated_at = (Get-Date).ToString("o")
        status = $Status
        source_cap = 75000
        retry_cap = 100000
        algorithms = @("ACBBA", "CBAA", "HIPC", "PI")
    }
    foreach ($key in $Extra.Keys) {
        $payload[$key] = $Extra[$key]
    }
    $temporary = "$watcherStatePath.tmp"
    $payload | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $watcherStatePath -Force
}

try {
    Write-WatcherState -Status "waiting_for_75000"
    if (Test-Path -LiteralPath $currentPidPath) {
        $currentPid = [int](Get-Content -LiteralPath $currentPidPath -Raw).Trim()
        while (Get-Process -Id $currentPid -ErrorAction SilentlyContinue) {
            Start-Sleep -Seconds 30
        }
    }

    $campaignStatePath = Join-Path $runRoot "transferred_coverage_state.json"
    $campaignState = Get-Content -LiteralPath $campaignStatePath -Raw | ConvertFrom-Json
    if (
        $campaignState.stage -ne "retry_selected" -or
        $campaignState.status -notin @("complete", "failed")
    ) {
        Write-WatcherState -Status "blocked" -Extra @{
            reason = "The 75000 retry run did not reach its validated merge state."
            campaign_stage = $campaignState.stage
            campaign_status = $campaignState.status
        }
        exit 2
    }

    $python = (Get-Command python -ErrorAction Stop).Source
    $arguments = @(
        "analysis/resume_coverage_sharded.py",
        "--workers", "$Workers",
        "--retry-cap", "100000",
        "--retry-only",
        "--retry-stage", "retry_100000",
        "--algorithms", "ACBBA", "CBAA", "HIPC", "PI",
        "--execute",
        "--allow-source-machine"
    )
    $coordinator = Start-Process `
        -FilePath $python `
        -ArgumentList $arguments `
        -WorkingDirectory $repoRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutPath `
        -RedirectStandardError $stderrPath `
        -PassThru
    $coordinator.Id | Set-Content -LiteralPath $followupPidPath -Encoding ASCII
    Write-WatcherState -Status "running_100000" -Extra @{
        coordinator_pid = $coordinator.Id
    }
    $coordinator.WaitForExit()
    Write-WatcherState -Status "finished_100000" -Extra @{
        coordinator_pid = $coordinator.Id
        exit_code = $coordinator.ExitCode
        note = "Any rows still failed after this pass remain logged as failed."
    }
    exit $coordinator.ExitCode
}
catch {
    Write-WatcherState -Status "watcher_failed" -Extra @{
        error = $_.Exception.Message
    }
    throw
}
